package main;

import modelo.*;

public class Main {

    public static void main(String[] args) {

        Central.iniciar();
        // central.cadastrar(central.criarJogador());
        // central.removerJogador("leticia");
        // central.adicionarPontuacao(2);
        // central.listar();
                /*
         while (central.login() == false) {
         central.login();*/
    }
		//central.iniciar();
    //central.procurarJogador();
}
